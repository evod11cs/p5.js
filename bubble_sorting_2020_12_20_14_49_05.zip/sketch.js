var bars = [];
var array;
var j = 0
var i = 0
function setup() {
  createCanvas(400, 400);
  array = r_array(30)
}

function draw() {
  background(0);
  if (i < array.length){
  if (j < array.length){
    if (array[j] < array[j + 1]) {
      t = array[j]
      array[j] = array[j + 1]
      array[j + 1] = t
    }
  j ++;
  }else{
    j = 0
    i ++;
  }
  }


  for (let i = 0; i < array.length; i++) {
    bars[i] = new Bar(array[i], i)
    bars[i].show()
  }
}