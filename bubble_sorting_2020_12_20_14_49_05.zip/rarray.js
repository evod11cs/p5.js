function r_array(n){
  data = []
  for (let i = 0;i<n;i++){
    data.push(random(10,30))
  }
  return data
}