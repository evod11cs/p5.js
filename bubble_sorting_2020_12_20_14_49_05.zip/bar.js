class Bar {
  constructor(h, n) {
    this.height = h
    this.size = width/array.length
    this.n = n
  }
  show() {
    noStroke()
    var x = this.n * this.size
    rect(x,height,this.size,-this.height*10)
  }
}