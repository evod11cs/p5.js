class Node {
  constructor(x, y) {
    this.left = null;
    this.right = null;
    this.type = null;
    this.value = null;
    this.x = x;
    this.y = y;
    this.offsetX = null;
    this.r = 0
  }

  addValue(val) {
    this.value = val
  }
  visit(parent,type) {
    if (this.left != null) {
      this.left.visit(this,'left')
    }
    if(this.r == 0){
      this.r = parent.r - 1
    }
      this.type = type
      let c = Chowk.bind(this)
      c(parent,this.type)
      if (this.right != null) {
      this.right.visit(this,'right')
    }
  }

  addNode(node) {
    let offt = 13
      let offsetY = 50
      if (this.value > node.value) {
      if (this.left == null) {
        this.left = node
          this.left.offsetX = this.offsetX - offt
          this.left.x = this.x - this.left.offsetX;
        this.left.y = this.y + offsetY;
        nodes.push(this.left)
      } else {
        this.left.addNode(node)
      }
    } else if (this.value < node.value) {
      if (this.right == null) {
        this.right = node
          this.right.offsetX = this.offsetX - offt
          this.right.x = this.x + this.right.offsetX;
        this.right.y = this.y + offsetY;
        nodes.push(this.right)
      } else {
        this.right.addNode(node)
      }
    }
  }
}