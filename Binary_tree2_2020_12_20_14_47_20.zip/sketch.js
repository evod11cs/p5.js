var tree;
var univa;
var nodes = [];
var nm = null
function setup() {
  createCanvas(600, 500);
  tree = new Tree()
    b = createButton('add')
    b1 = createButton('restart')
    b1.mousePressed(()=> {
      tree.root = null
      nodes = []
    })
    b.mousePressed(handleAdd)
    univa = createP('l')
}
function handleAdd() {
  tree.addNode(int(random(0, 100)))
}

function mouseDragged(){
  if (nodes.length > 0){
    nodes.forEach(xt=>{
      let d = dist(mouseX,mouseY,xt.x,xt.y)
      if (d < 10){
        if(!nm){
        nm = xt
      }
        nm.x = mouseX
        nm.y = mouseY
      }
    })
  }
}
function mouseReleased(){
  nm = null
}
function unival(node) {
  if (node.left == null && node.right == null){
  return 1
  }
  else if (node.left != null && node.right != null){
    return unival(node.left) + unival(node.right)
  }
  else if (node.left != null){
  return unival(node.left)
  }
  else{
  return unival(node.right)
  }
}

function draw() {
  background(220);
  stroke(1)
  fill(0)
  textAlign(CENTER)
  text('right',40,15)
  text('left',40,45)
  fill(200,30,30)
  circle(10,10,20,20)
  fill(255)
  circle(10,40,20,20)
  if (tree.root != null) {
    univa.html(unival(tree.root))
    tree.traverse()
  }
}