function Chowk(parent,type) {
  push()
  if(type == 'left'){
  fill(255)
  }else if(type == 'right'){
    fill(200,30,30)
  }else{
  fill(40,200,40)
  }
  line(parent.x, parent.y + 10, this.x, this.y)
  ellipse(this.x, this.y, parent.r, parent.r)
  textAlign(CENTER)
  textSize(this.r/1.3)
  fill(0)
  noStroke()
  text(this.value, this.x, this.y + 5)
  pop()
}