var bars = [];
var array;
var i = 0
function setup() {
  createCanvas(400, 400);
  array = r_array(400)
}

function draw() {
  background(255);
    currentValue = array[i]
    j = i - 1
    while (j >= 0 && array[j] > currentValue ){
      array[j + 1] = array[j]
      j--;
    }
    array[j+1] = currentValue
  i++;

  for (let k = 0; k < array.length; k++) {
    // bars[i] = new Bar(array[i], i)
    // bars[i].show()
    line(k,array[k]*height,k,height)
  }
}