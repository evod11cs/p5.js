class Stack{
  constructor(){
    this.items = []
  }
  
  remove(){
    return this.items.pop()
  }
  
  add(elt){
    this.items.push(elt)
  }
  
  isEmpty(){
    return this.items.length === 0
  }
  
}

class Node{
  constructor(value){
    this.left = undefined
    this.right = undefined
    this.value = value
    this.state = false
    this.x = width/2
    this.y = 20
    this.parent = []
  }
  show(c){
    noFill()
    if(c){
    stroke(c)
      strokeWeight(2)
    }
    circle(this.x,this.y,30)
    stroke(0)
    if(this.parent.length != 0){
      for(let i = 0;i<this.parent.length;i++)
          line(this.x,this.y,this.parent[i].x,this.parent[i].y)
    }
  }
  add(x,y){
    x.y = this.y + 40
    x.x = this.x +  20
    if (y){
    y.y = this.y + 40
    y.x = this.x -  20
    y.parent.push(this)
    }
    this.left = x
    this.right = y
    this.left.parent.push(this)
  }
  check(){
    this.state = true
  }
  isChecked(){
    return this.state
  }
  adjacentEdges(){
    return [this.left,this.right]
  }
}