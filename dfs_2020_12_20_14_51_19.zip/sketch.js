var root,x1,x2,x3,x4,x5
let y0 = 0
let x0 = 0
function setup() {
  let y0 = 40
  let x0 = width
  createCanvas(400, 400);
  root = new Node(0)
  x3 = new Node(3)
  x1 = new Node(1)
  x2 = new Node(2)
  x5 = new Node(5)
  x4 = new Node(4)
  x1.add(x3,x4)
  x2.add(x4,x5)
  root.add(x1,x2)
  root.x = x0
  root.y = y0
  recur(root)
}

function draw() {
  background(220);
  root.show()
  x1.show()
  x2.show()
  x3.show()
  x4.show()
  x5.show()
  dfs(root,x3)
  for(let i = 0;i<path.items.length;i++){
    path.items[i].show("red")
  }
  noLoop()
}

function recur(node){
  if (node.left){
    node.left.x = node.x - 20
    node.left.y = node.y + 40
    recur(node.left,node)
  }
  if (node.right){
    node.right.x = node.x + 20
    node.right.y = node.y + 40
    recur(node.right,node)
  }
  return
}
  
let path = new Stack()
function dfs(root,goal){
  s = new Stack()
  s.add(root)
  while (!s.isEmpty()){
    v = s.remove()
    path.add(v)
    if (goal === v){
      return v
    }else{
      if (!v.left){
        path.remove()
      }
    }
    if (!v.isChecked()){
      v.check()
      for (let i = 0;i<v.adjacentEdges().length;i++){
        w = v.adjacentEdges()[i]
        if (w == undefined){
          break
        }
        s.add(w)
      }
    }
  }
}