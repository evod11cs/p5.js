class Bar {
  constructor(h, n) {
    this.height = h
    this.n = n
  }
  show() {
    // rect(x,height,this.size,-this.height*10)
    line(this.n,this.height*height,this.n,height)
  }
}