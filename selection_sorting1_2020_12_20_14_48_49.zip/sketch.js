var bars = [];
var array;
var i = 0
function setup() {
  createCanvas(400, 400);
  array = r_array(400)
}

function draw() {
  background(255);
  if (i < array.length){
  for (let j = 0;j<array.length;j++){
    if (array[j] < array[j + 1]) {
      t = array[j]
      array[j] = array[j + 1]
      array[j + 1] = t
    }
  }
  i++;
  }

  for (let i = 0; i < array.length; i++) {
    bars[i] = new Bar(array[i], i)
    bars[i].show()
  }
}